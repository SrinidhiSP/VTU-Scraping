# VTUMarksScraping

a program to scrape marks from the vtu4u website
